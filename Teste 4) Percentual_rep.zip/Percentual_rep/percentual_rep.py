import json

def percentual_rep():
    try:
        with open('Faturamentoporestado.json', 'r') as file:
            data = json.load(file)
            faturamento = {}
            for estado, valor in data['faturamento_por_estado'].items():
                valor = float(valor.replace('R$', '').replace('.', '').replace(',', '.'))
                faturamento[estado] = valor
            return faturamento
    except FileNotFoundError:
        print("Arquivo 'Faturamentoporestado.json' não encontrado.")
        return {}
    except Exception as e:
        print(f"Erro ao ler o arquivo: {e}")
        return {}


valor_total = sum(percentual_rep().values())


print("Percentual de representação por estado:")
for estado, valor in percentual_rep().items():
    percentual = (valor / valor_total) * 100
    print(f"{estado}: {percentual:.2f}%")
